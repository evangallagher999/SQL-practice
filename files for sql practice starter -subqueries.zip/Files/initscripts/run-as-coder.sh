# Add any commands or scripts that you wish to run as coder here
/usr/pgadmin4/bin/pgadmin4
