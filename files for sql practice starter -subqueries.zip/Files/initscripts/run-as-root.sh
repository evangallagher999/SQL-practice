# Add any commands or scripts that you wish to run as root here
systemctl restart postgresql@14-main.service &
systemctl restart apache2 &
#/usr/pgadmin4/bin/pgadmin4
